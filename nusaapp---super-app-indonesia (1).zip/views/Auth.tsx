import React, { useState } from 'react';
import { 
  User, Bike, Store, ShieldAlert, ArrowRight, ChevronLeft, 
  Smartphone, Mail, Lock, CheckCircle2, Upload, MapPin, Camera 
} from 'lucide-react';
import { UserRole } from '../types';

interface AuthProps {
  onLogin: (role: UserRole, data: any) => void;
}

type AuthMode = 'landing' | 'login' | 'register-select' | 'register-form' | 'success';

const Auth: React.FC<AuthProps> = ({ onLogin }) => {
  const [mode, setMode] = useState<AuthMode>('landing');
  const [selectedRole, setSelectedRole] = useState<UserRole>(UserRole.USER);
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    email: '',
    password: '',
    vehicleType: 'Motor',
    plateNumber: '',
    storeName: '',
    storeCategory: 'Makanan',
    address: '',
    staffKey: ''
  });

  const handleRoleSelect = (role: UserRole) => {
    setSelectedRole(role);
    setMode('register-form');
    setStep(1);
  };

  const renderHeader = (title: string, subtitle: string) => (
    <div className="mb-8">
      <button 
        onClick={() => setMode(mode === 'register-form' ? 'register-select' : 'landing')}
        className="mb-4 p-2 -ml-2 hover:bg-slate-100 rounded-full transition-colors"
      >
        <ChevronLeft size={24} />
      </button>
      <h1 className="text-3xl font-extrabold text-slate-900 tracking-tight">{title}</h1>
      <p className="text-slate-500 mt-2 font-medium">{subtitle}</p>
    </div>
  );

  const Landing = () => (
    <div className="h-full flex flex-col justify-between py-12 px-6 animate-in fade-in duration-500">
      <div className="mt-10">
        <div className="w-20 h-20 bg-violet-600 rounded-[28px] flex items-center justify-center shadow-xl shadow-violet-100 mb-8 transform -rotate-6">
          <span className="text-white text-4xl font-black">N</span>
        </div>
        <h1 className="text-4xl font-black text-slate-900 leading-tight">
          Semua yang kamu butuh,<br />
          <span className="text-violet-600 underline decoration-violet-100 underline-offset-8">Ada di satu aplikasi.</span>
        </h1>
        <p className="text-slate-500 mt-6 text-lg font-medium">
          Bergabung dengan NusaApp dan nikmati kemudahan masa depan.
        </p>
      </div>

      <div className="space-y-4">
        <button 
          onClick={() => setMode('login')}
          className="w-full bg-violet-600 text-white py-5 rounded-3xl font-bold text-lg shadow-lg shadow-violet-100 active:scale-95 transition-all"
        >
          Masuk Sekarang
        </button>
        <button 
          onClick={() => setMode('register-select')}
          className="w-full bg-white text-slate-700 py-5 rounded-3xl font-bold text-lg border-2 border-slate-100 active:scale-95 transition-all"
        >
          Daftar Akun Baru
        </button>
      </div>
    </div>
  );

  const RegisterSelect = () => (
    <div className="py-12 px-6 animate-in slide-in-from-bottom-8 duration-500">
      {renderHeader("Mari Bergabung", "Bagaimana Anda ingin menggunakan NusaApp?")}
      
      <div className="grid gap-4">
        {[
          { id: UserRole.USER, label: 'Sebagai Pelanggan', icon: User, desc: 'Pesan kendaraan, belanja, dan bayar praktis.', color: 'violet' },
          { id: UserRole.DRIVER, label: 'Sebagai Mitra Driver', icon: Bike, desc: 'Dapatkan penghasilan dengan waktu fleksibel.', color: 'blue' },
          { id: UserRole.MERCHANT, label: 'Sebagai Mitra Toko', icon: Store, desc: 'Kembangkan bisnismu bersama kami.', color: 'orange' },
          { id: UserRole.ADMIN, label: 'Sebagai Staf', icon: ShieldAlert, desc: 'Akses administrasi internal.', color: 'purple' },
        ].map((role) => (
          <button 
            key={role.id}
            onClick={() => handleRoleSelect(role.id)}
            className="flex items-center gap-5 p-6 bg-white border-2 border-slate-50 rounded-[32px] hover:border-violet-500 hover:shadow-xl hover:shadow-violet-50 transition-all group text-left"
          >
            <div className={`w-14 h-14 rounded-2xl flex items-center justify-center bg-slate-50 text-slate-600 group-hover:bg-violet-600 group-hover:text-white transition-colors`}>
              <role.icon size={28} />
            </div>
            <div className="flex-1">
              <h3 className="font-bold text-slate-800">{role.label}</h3>
              <p className="text-xs text-slate-500 font-medium">{role.desc}</p>
            </div>
            <ArrowRight size={20} className="text-slate-300 group-hover:text-violet-500 group-hover:translate-x-1 transition-all" />
          </button>
        ))}
      </div>
    </div>
  );

  const RegisterForm = () => {
    const isLastStep = (selectedRole === UserRole.USER && step === 1) || 
                      (selectedRole === UserRole.DRIVER && step === 2) || 
                      (selectedRole === UserRole.MERCHANT && step === 2) ||
                      (selectedRole === UserRole.ADMIN && step === 1);

    const handleSubmit = () => {
      if (isLastStep) {
        setMode('success');
      } else {
        setStep(step + 1);
      }
    };

    return (
      <div className="py-12 px-6 animate-in slide-in-from-right-8 duration-500">
        {renderHeader(`Daftar sebagai ${selectedRole === UserRole.USER ? 'Pelanggan' : selectedRole === UserRole.DRIVER ? 'Driver' : selectedRole === UserRole.MERCHANT ? 'Mitra Toko' : 'Staf'}`, `Langkah ${step} dari ${selectedRole === UserRole.USER || selectedRole === UserRole.ADMIN ? 1 : 2}`)}
        
        <div className="space-y-5">
          {step === 1 && (
            <>
              <div className="space-y-2">
                <label className="text-xs font-bold text-slate-400 uppercase tracking-widest ml-1">Nama Lengkap</label>
                <div className="relative">
                  <User className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={20} />
                  <input 
                    className="w-full bg-slate-50 border border-slate-100 rounded-2xl py-4 pl-12 pr-4 font-bold text-sm focus:ring-2 focus:ring-violet-500 outline-none transition-all"
                    placeholder="Masukkan nama Anda"
                    value={formData.name}
                    onChange={(e) => setFormData({...formData, name: e.target.value})}
                  />
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-xs font-bold text-slate-400 uppercase tracking-widest ml-1">Nomor Handphone</label>
                <div className="relative">
                  <Smartphone className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={20} />
                  <input 
                    className="w-full bg-slate-50 border border-slate-100 rounded-2xl py-4 pl-12 pr-4 font-bold text-sm focus:ring-2 focus:ring-violet-500 outline-none transition-all"
                    placeholder="Contoh: 0812..."
                    value={formData.phone}
                    onChange={(e) => setFormData({...formData, phone: e.target.value})}
                  />
                </div>
              </div>

              {selectedRole === UserRole.ADMIN && (
                <div className="space-y-2">
                  <label className="text-xs font-bold text-slate-400 uppercase tracking-widest ml-1">Kunci Rahasia Staf</label>
                  <div className="relative">
                    <Lock className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={20} />
                    <input 
                      type="password"
                      className="w-full bg-slate-50 border border-slate-100 rounded-2xl py-4 pl-12 pr-4 font-bold text-sm focus:ring-2 focus:ring-violet-500 outline-none transition-all"
                      placeholder="Masukkan 16 digit kunci"
                      value={formData.staffKey}
                      onChange={(e) => setFormData({...formData, staffKey: e.target.value})}
                    />
                  </div>
                </div>
              )}
            </>
          )}

          {step === 2 && selectedRole === UserRole.DRIVER && (
            <>
              <div className="space-y-2">
                <label className="text-xs font-bold text-slate-400 uppercase tracking-widest ml-1">Jenis Kendaraan</label>
                <select 
                  className="w-full bg-slate-50 border border-slate-100 rounded-2xl py-4 px-4 font-bold text-sm focus:ring-2 focus:ring-violet-500 outline-none transition-all"
                  value={formData.vehicleType}
                  onChange={(e) => setFormData({...formData, vehicleType: e.target.value})}
                >
                  <option>Motor</option>
                  <option>Mobil (4-penumpang)</option>
                  <option>Mobil (6-penumpang)</option>
                  <option>Box / Pickup</option>
                </select>
              </div>
              <div className="space-y-2">
                <label className="text-xs font-bold text-slate-400 uppercase tracking-widest ml-1">Nomor Plat Kendaraan</label>
                <input 
                  className="w-full bg-slate-50 border border-slate-100 rounded-2xl py-4 px-4 font-bold text-sm focus:ring-2 focus:ring-violet-500 outline-none transition-all"
                  placeholder="B 1234 ABC"
                  value={formData.plateNumber}
                  onChange={(e) => setFormData({...formData, plateNumber: e.target.value})}
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                 <button className="flex flex-col items-center gap-2 p-6 border-2 border-dashed border-slate-200 rounded-3xl text-slate-400">
                    <Camera size={24} />
                    <span className="text-[10px] font-bold">Foto KTP</span>
                 </button>
                 <button className="flex flex-col items-center gap-2 p-6 border-2 border-dashed border-slate-200 rounded-3xl text-slate-400">
                    <Upload size={24} />
                    <span className="text-[10px] font-bold">Foto SIM</span>
                 </button>
              </div>
            </>
          )}

          {step === 2 && selectedRole === UserRole.MERCHANT && (
            <>
              <div className="space-y-2">
                <label className="text-xs font-bold text-slate-400 uppercase tracking-widest ml-1">Nama Toko</label>
                <div className="relative">
                  <Store className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={20} />
                  <input 
                    className="w-full bg-slate-50 border border-slate-100 rounded-2xl py-4 pl-12 pr-4 font-bold text-sm focus:ring-2 focus:ring-violet-500 outline-none transition-all"
                    placeholder="Toko Saya"
                    value={formData.storeName}
                    onChange={(e) => setFormData({...formData, storeName: e.target.value})}
                  />
                </div>
              </div>
              <div className="space-y-2">
                <label className="text-xs font-bold text-slate-400 uppercase tracking-widest ml-1">Alamat Bisnis</label>
                <div className="relative">
                  <MapPin className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={20} />
                  <input 
                    className="w-full bg-slate-50 border border-slate-100 rounded-2xl py-4 pl-12 pr-4 font-bold text-sm focus:ring-2 focus:ring-violet-500 outline-none transition-all"
                    placeholder="Cari gedung atau jalan"
                    value={formData.address}
                    onChange={(e) => setFormData({...formData, address: e.target.value})}
                  />
                </div>
              </div>
              <div className="space-y-2">
                <label className="text-xs font-bold text-slate-400 uppercase tracking-widest ml-1">Kategori</label>
                <div className="flex gap-2 overflow-x-auto no-scrollbar pb-1">
                   {['Makanan', 'Elektronik', 'Swalayan', 'Apotek'].map(c => (
                     <button 
                       key={c}
                       onClick={() => setFormData({...formData, storeCategory: c})}
                       className={`px-4 py-2 rounded-full text-xs font-bold whitespace-nowrap transition-all ${
                         formData.storeCategory === c ? 'bg-violet-600 text-white' : 'bg-slate-100 text-slate-500'
                       }`}
                     >
                       {c}
                     </button>
                   ))}
                </div>
              </div>
            </>
          )}

          <button 
            onClick={handleSubmit}
            className="w-full bg-violet-600 text-white py-5 rounded-3xl font-bold text-lg shadow-lg shadow-violet-100 active:scale-95 transition-all mt-6"
          >
            {isLastStep ? 'Selesaikan Pendaftaran' : 'Langkah Selanjutnya'}
          </button>
        </div>
      </div>
    );
  };

  const Success = () => (
    <div className="h-full flex flex-col items-center justify-center py-12 px-10 text-center animate-in zoom-in-95 duration-500">
      <div className="w-24 h-24 bg-violet-100 text-violet-600 rounded-full flex items-center justify-center mb-8 animate-bounce">
        <CheckCircle2 size={48} />
      </div>
      <h1 className="text-3xl font-black text-slate-900 mb-4">Registrasi Berhasil!</h1>
      <p className="text-slate-500 font-medium mb-10 leading-relaxed">
        Selamat datang di keluarga besar NusaApp. Akun Anda telah siap. Mulai jelajahi sekarang.
      </p>
      <button 
        onClick={() => onLogin(selectedRole, formData)}
        className="w-full bg-violet-600 text-white py-5 rounded-3xl font-bold text-lg shadow-lg"
      >
        Ke Dashboard
      </button>
    </div>
  );

  const Login = () => (
    <div className="py-12 px-6 animate-in slide-in-from-left-8 duration-500">
      {renderHeader("Selamat Datang Kembali", "Silakan masuk ke akun Anda")}
      <div className="space-y-6">
        <div className="space-y-2">
          <label className="text-xs font-bold text-slate-400 uppercase tracking-widest">Nomor HP atau Email</label>
          <div className="relative">
            <Mail className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={20} />
            <input 
              className="w-full bg-slate-50 border border-slate-100 rounded-2xl py-4 pl-12 pr-4 font-bold text-sm focus:ring-2 focus:ring-violet-500 outline-none transition-all"
              placeholder="0812 atau email@domain.com"
            />
          </div>
        </div>
        <div className="space-y-2">
          <label className="text-xs font-bold text-slate-400 uppercase tracking-widest">Kata Sandi</label>
          <div className="relative">
            <Lock className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={20} />
            <input 
              type="password"
              className="w-full bg-slate-50 border border-slate-100 rounded-2xl py-4 pl-12 pr-4 font-bold text-sm focus:ring-2 focus:ring-violet-500 outline-none transition-all"
              placeholder="••••••••"
            />
          </div>
        </div>
        <button 
          onClick={() => onLogin(UserRole.USER, {})}
          className="w-full bg-violet-600 text-white py-5 rounded-3xl font-bold text-lg shadow-lg active:scale-95 transition-all mt-4"
        >
          Masuk
        </button>
        <p className="text-center text-sm text-slate-500 font-medium">
          Belum punya akun? <span onClick={() => setMode('register-select')} className="text-violet-600 font-bold cursor-pointer underline">Daftar</span>
        </p>
      </div>
    </div>
  );

  return (
    <div className="h-full bg-white overflow-y-auto no-scrollbar">
      {mode === 'landing' && <Landing />}
      {mode === 'register-select' && <RegisterSelect />}
      {mode === 'register-form' && <RegisterForm />}
      {mode === 'login' && <Login />}
      {mode === 'success' && <Success />}
    </div>
  );
};

export default Auth;